package com.rootdiscover.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Category(
    val id: String,
    val name: String,
    val short: String,
    val count: Int,
    val source: String,
)

data class RootApp(
    val name: String,
    val url: String,
    val github: Boolean,
    val description: String,
    val category: String,
    val section: String,
    val featured: Boolean,
    val foss: Boolean,
    val fdroid: Boolean,
    val play: Boolean,
    val frameworks: List<String>,
) {
    /** Lower-cased text used for searching. */
    val searchText: String = listOf(name, description, section, category).joinToString(" ").lowercase()
}

data class Brand(
    val brand: String,
    val status: String,
    val method: String,
    val wait: String,
    val limitation: String,
    val guidance: String,
    val guide: String,
)

data class TempRoot(
    val project: String,
    val url: String,
    val devices: String,
    val firmware: String,
    val notes: String,
)

data class FrameworkPick(val want: String, val choose: String, val why: String)

data class RootData(
    val source: String,
    val license: String,
    val generated: String,
    val categories: List<Category>,
    val apps: List<RootApp>,
    val brands: List<Brand>,
    val tempRoot: List<TempRoot>,
    val frameworkPicks: List<FrameworkPick>,
)

/** Loads the bundled catalogue (assets/root_data.json) once and caches it. */
object DataRepository {
    @Volatile
    private var cached: RootData? = null

    fun load(context: Context): RootData {
        cached?.let { return it }
        synchronized(this) {
            cached?.let { return it }
            val text = context.assets.open("root_data.json").bufferedReader(Charsets.UTF_8).use { it.readText() }
            val data = parse(JSONObject(text))
            cached = data
            return data
        }
    }

    private fun parse(o: JSONObject): RootData = RootData(
        source = o.optString("source"),
        license = o.optString("license"),
        generated = o.optString("generated"),
        categories = o.optJSONArray("categories").objects().map {
            Category(
                id = it.optString("id"),
                name = it.optString("name"),
                short = it.optString("short", it.optString("name")),
                count = it.optInt("count"),
                source = it.optString("source"),
            )
        },
        apps = o.optJSONArray("apps").objects().map {
            RootApp(
                name = it.optString("name"),
                url = it.optString("url"),
                github = it.optBoolean("github"),
                description = it.optString("description"),
                category = it.optString("category"),
                section = it.optString("section"),
                featured = it.optBoolean("featured"),
                foss = it.optBoolean("foss"),
                fdroid = it.optBoolean("fdroid"),
                play = it.optBoolean("play"),
                frameworks = it.optJSONArray("frameworks").strings(),
            )
        },
        brands = o.optJSONArray("brands").objects().map {
            Brand(
                brand = it.optString("brand"),
                status = it.optString("status"),
                method = it.optString("method"),
                wait = it.optString("wait"),
                limitation = it.optString("limitation"),
                guidance = it.optString("guidance"),
                guide = it.optString("guide"),
            )
        },
        tempRoot = o.optJSONArray("tempRoot").objects().map {
            TempRoot(
                project = it.optString("project"),
                url = it.optString("url"),
                devices = it.optString("devices"),
                firmware = it.optString("firmware"),
                notes = it.optString("notes"),
            )
        },
        frameworkPicks = o.optJSONArray("frameworkPicks").objects().map {
            FrameworkPick(it.optString("want"), it.optString("choose"), it.optString("why"))
        },
    )

    private fun JSONArray?.objects(): List<JSONObject> {
        if (this == null) return emptyList()
        return (0 until length()).mapNotNull { optJSONObject(it) }
    }

    private fun JSONArray?.strings(): List<String> {
        if (this == null) return emptyList()
        return (0 until length()).map { optString(it) }
    }
}

/** Human-readable framework names for the badge codes used by Awesome Android Root. */
fun frameworkLabel(code: String): String = when (code) {
    "M" -> "Magisk"
    "K" -> "KernelSU"
    "A" -> "APatch"
    "LSP" -> "LSPosed"
    else -> code
}

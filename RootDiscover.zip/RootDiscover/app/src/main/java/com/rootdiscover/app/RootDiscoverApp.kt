package com.rootdiscover.app

import android.app.Application
import com.google.android.material.color.DynamicColors

class RootDiscoverApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // Use Material You wallpaper colours on Android 12+, fall back to the green theme elsewhere.
        DynamicColors.applyToActivitiesIfAvailable(this)
    }
}

package com.rootdiscover.app

import android.content.res.ColorStateList
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView

/* ----------------------------- Apps list ----------------------------- */

class AppsAdapter(
    private val categoryNames: Map<String, String>,
) : RecyclerView.Adapter<AppsAdapter.Holder>() {

    private var items: List<RootApp> = emptyList()

    fun submit(list: List<RootApp>) {
        items = list
        notifyDataSetChanged()
    }

    override fun getItemCount() = items.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false)
        return Holder(view)
    }

    override fun onBindViewHolder(holder: Holder, position: Int) = holder.bind(items[position])

    inner class Holder(view: View) : RecyclerView.ViewHolder(view) {
        private val name: TextView = view.findViewById(R.id.app_name)
        private val star: TextView = view.findViewById(R.id.app_star)
        private val meta: TextView = view.findViewById(R.id.app_meta)
        private val desc: TextView = view.findViewById(R.id.app_desc)
        private val badges: TextView = view.findViewById(R.id.app_badges)
        private val link: TextView = view.findViewById(R.id.app_link)

        fun bind(app: RootApp) {
            name.text = app.name
            star.visibility = if (app.featured) View.VISIBLE else View.GONE

            val category = categoryNames[app.category] ?: app.category
            meta.text = if (app.section.isNotBlank() && app.section != category) "$category · ${app.section}" else category

            desc.text = app.description
            desc.visibility = if (app.description.isBlank()) View.GONE else View.VISIBLE

            val parts = mutableListOf<String>()
            parts += if (app.foss) "FOSS" else "Proprietary"
            app.frameworks.forEach { parts += frameworkLabel(it) }
            if (app.fdroid) parts += "F-Droid"
            if (app.play) parts += "Play Store"
            badges.text = parts.joinToString("  ·  ")

            link.text = (if (app.github) "GitHub: " else "Website: ") + Links.pretty(app.url)

            itemView.setOnClickListener { Links.open(it.context, app.url) }
            itemView.setOnLongClickListener {
                Links.copy(it.context, app.name, app.url)
                true
            }
        }
    }
}

/* ---------------------------- Devices list ---------------------------- */

sealed class DeviceRow {
    data class Header(val title: String, val subtitle: String) : DeviceRow()
    data class BrandRow(val brand: Brand) : DeviceRow()
    data class TempRow(val temp: TempRoot) : DeviceRow()
    data class PickRow(val pick: FrameworkPick) : DeviceRow()
}

class DevicesAdapter(private val rows: List<DeviceRow>) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    override fun getItemCount() = rows.size

    override fun getItemViewType(position: Int) = when (rows[position]) {
        is DeviceRow.Header -> 0
        is DeviceRow.BrandRow -> 1
        is DeviceRow.TempRow -> 2
        is DeviceRow.PickRow -> 3
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return when (viewType) {
            0 -> HeaderHolder(inflater.inflate(R.layout.item_header, parent, false))
            1 -> BrandHolder(inflater.inflate(R.layout.item_brand, parent, false))
            2 -> TempHolder(inflater.inflate(R.layout.item_temp, parent, false))
            else -> PickHolder(inflater.inflate(R.layout.item_pick, parent, false))
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (val row = rows[position]) {
            is DeviceRow.Header -> (holder as HeaderHolder).bind(row)
            is DeviceRow.BrandRow -> (holder as BrandHolder).bind(row.brand)
            is DeviceRow.TempRow -> (holder as TempHolder).bind(row.temp)
            is DeviceRow.PickRow -> (holder as PickHolder).bind(row.pick)
        }
    }

    class HeaderHolder(view: View) : RecyclerView.ViewHolder(view) {
        private val title: TextView = view.findViewById(R.id.header_title)
        private val subtitle: TextView = view.findViewById(R.id.header_subtitle)
        fun bind(row: DeviceRow.Header) {
            title.text = row.title
            subtitle.text = row.subtitle
            subtitle.visibility = if (row.subtitle.isBlank()) View.GONE else View.VISIBLE
        }
    }

    class BrandHolder(view: View) : RecyclerView.ViewHolder(view) {
        private val name: TextView = view.findViewById(R.id.brand_name)
        private val status: TextView = view.findViewById(R.id.brand_status)
        private val method: TextView = view.findViewById(R.id.brand_method)
        private val limit: TextView = view.findViewById(R.id.brand_limit)
        private val guidance: TextView = view.findViewById(R.id.brand_guidance)

        fun bind(brand: Brand) {
            val ctx = itemView.context
            name.text = brand.brand

            val (label, colorRes) = when (brand.status) {
                "easy" -> "Easy" to R.color.status_easy
                "moderate" -> "Model-dependent" to R.color.status_moderate
                "restricted" -> "Restricted" to R.color.status_restricted
                else -> "Not available" to R.color.status_unavailable
            }
            status.text = label
            status.backgroundTintList = ColorStateList.valueOf(ContextCompat.getColor(ctx, colorRes))
            status.setTextColor(if (brand.status == "moderate") Color.BLACK else Color.WHITE)

            val wait = if (brand.wait.isNotBlank()) "  ·  Wait: ${brand.wait}" else ""
            method.text = "Unlock: ${brand.method.ifBlank { "Unknown" }}$wait"

            limit.text = brand.limitation
            limit.visibility = if (brand.limitation.isBlank()) View.GONE else View.VISIBLE
            guidance.text = brand.guidance
            guidance.visibility = if (brand.guidance.isBlank() || brand.guidance == brand.limitation) View.GONE else View.VISIBLE

            itemView.setOnClickListener { Links.open(it.context, brand.guide) }
            itemView.setOnLongClickListener {
                Links.copy(it.context, brand.brand, brand.guide)
                true
            }
        }
    }

    class TempHolder(view: View) : RecyclerView.ViewHolder(view) {
        private val project: TextView = view.findViewById(R.id.temp_project)
        private val devices: TextView = view.findViewById(R.id.temp_devices)
        private val firmware: TextView = view.findViewById(R.id.temp_firmware)
        private val notes: TextView = view.findViewById(R.id.temp_notes)
        private val link: TextView = view.findViewById(R.id.temp_link)

        fun bind(t: TempRoot) {
            project.text = t.project
            devices.text = t.devices
            firmware.text = t.firmware
            firmware.visibility = if (t.firmware.isBlank()) View.GONE else View.VISIBLE
            notes.text = t.notes
            notes.visibility = if (t.notes.isBlank()) View.GONE else View.VISIBLE
            link.text = "GitHub: " + Links.pretty(t.url)
            itemView.setOnClickListener { Links.open(it.context, t.url) }
            itemView.setOnLongClickListener {
                Links.copy(it.context, t.project, t.url)
                true
            }
        }
    }

    class PickHolder(view: View) : RecyclerView.ViewHolder(view) {
        private val want: TextView = view.findViewById(R.id.pick_want)
        private val choose: TextView = view.findViewById(R.id.pick_choose)
        private val why: TextView = view.findViewById(R.id.pick_why)
        fun bind(p: FrameworkPick) {
            want.text = p.want
            choose.text = p.choose
            why.text = p.why
        }
    }
}

package com.rootdiscover.app

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.button.MaterialButton
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.google.android.material.textfield.TextInputEditText

class MainActivity : AppCompatActivity() {

    private lateinit var data: RootData
    private lateinit var toolbar: MaterialToolbar
    private lateinit var bottomNav: BottomNavigationView
    private lateinit var pageApps: View
    private lateinit var pageDevices: View
    private lateinit var pageAbout: View

    private lateinit var appsAdapter: AppsAdapter
    private lateinit var appsList: RecyclerView
    private lateinit var resultCount: TextView
    private lateinit var emptyView: TextView
    private lateinit var chipFeatured: Chip
    private lateinit var chipGithub: Chip

    private var query = ""
    private var selectedCategory: String? = null   // null = all categories

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val root: View = findViewById(R.id.root)
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            // Bottom inset is handled by BottomNavigationView itself.
            v.setPadding(bars.left, bars.top, bars.right, 0)
            insets
        }

        data = DataRepository.load(this)

        toolbar = findViewById(R.id.toolbar)
        bottomNav = findViewById(R.id.bottom_nav)
        pageApps = findViewById(R.id.page_apps)
        pageDevices = findViewById(R.id.devices_list)
        pageAbout = findViewById(R.id.page_about)

        savedInstanceState?.let {
            query = it.getString(KEY_QUERY, "")
            selectedCategory = it.getString(KEY_CATEGORY)
        }

        setupAppsPage(savedInstanceState)
        setupDevicesPage()
        setupAboutPage()

        bottomNav.setOnItemSelectedListener { item ->
            showPage(item.itemId)
            true
        }
        bottomNav.setOnItemReselectedListener { item ->
            when (item.itemId) {
                R.id.nav_apps -> appsList.smoothScrollToPosition(0)
                R.id.nav_devices -> (pageDevices as RecyclerView).smoothScrollToPosition(0)
            }
        }
        val tab = savedInstanceState?.getInt(KEY_TAB, R.id.nav_apps) ?: R.id.nav_apps
        bottomNav.selectedItemId = tab
        showPage(tab)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (bottomNav.selectedItemId != R.id.nav_apps) {
                    bottomNav.selectedItemId = R.id.nav_apps
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                    isEnabled = true
                }
            }
        })
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt(KEY_TAB, bottomNav.selectedItemId)
        outState.putString(KEY_QUERY, query)
        outState.putString(KEY_CATEGORY, selectedCategory)
        outState.putBoolean(KEY_FEATURED, chipFeatured.isChecked)
        outState.putBoolean(KEY_GITHUB, chipGithub.isChecked)
    }

    private fun showPage(itemId: Int) {
        pageApps.visibility = if (itemId == R.id.nav_apps) View.VISIBLE else View.GONE
        pageDevices.visibility = if (itemId == R.id.nav_devices) View.VISIBLE else View.GONE
        pageAbout.visibility = if (itemId == R.id.nav_about) View.VISIBLE else View.GONE
        toolbar.subtitle = when (itemId) {
            R.id.nav_apps -> "${data.apps.size} root apps & modules"
            R.id.nav_devices -> "Supported devices & unlock status"
            else -> "About & sources"
        }
    }

    /* ------------------------------ Apps ------------------------------ */

    private fun setupAppsPage(state: Bundle?) {
        appsList = findViewById(R.id.apps_list)
        resultCount = findViewById(R.id.result_count)
        emptyView = findViewById(R.id.empty_view)
        chipFeatured = findViewById(R.id.chip_featured)
        chipGithub = findViewById(R.id.chip_github)

        appsAdapter = AppsAdapter(data.categories.associate { it.id to it.short })
        appsList.layoutManager = LinearLayoutManager(this)
        appsList.adapter = appsAdapter

        // Category chips: "All" + one per category.
        val group: ChipGroup = findViewById(R.id.category_chips)
        val inflater = LayoutInflater.from(this)
        fun addChip(label: String, categoryId: String?) {
            val chip = inflater.inflate(R.layout.item_chip, group, false) as Chip
            chip.id = View.generateViewId()
            chip.text = label
            chip.tag = categoryId
            chip.isSaveEnabled = false   // selection is restored from our own saved state
            chip.isChecked = categoryId == selectedCategory
            group.addView(chip)
        }
        addChip(getString(R.string.filter_all) + " (${data.apps.size})", null)
        data.categories.forEach { addChip("${it.short} (${it.count})", it.id) }
        group.setOnCheckedStateChangeListener { g, checkedIds ->
            val chip = checkedIds.firstOrNull()?.let { g.findViewById<Chip>(it) }
            selectedCategory = chip?.tag as String?
            applyFilters(scrollToTop = true)
        }

        chipFeatured.isChecked = state?.getBoolean(KEY_FEATURED) ?: false
        chipGithub.isChecked = state?.getBoolean(KEY_GITHUB) ?: false
        chipFeatured.setOnCheckedChangeListener { _, _ -> applyFilters(scrollToTop = true) }
        chipGithub.setOnCheckedChangeListener { _, _ -> applyFilters(scrollToTop = true) }

        val search: TextInputEditText = findViewById(R.id.search_input)
        if (query.isNotEmpty()) search.setText(query)
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                query = s?.toString().orEmpty()
                applyFilters(scrollToTop = true)
            }
        })

        applyFilters(scrollToTop = false)
    }

    private fun applyFilters(scrollToTop: Boolean) {
        val terms = query.trim().lowercase().split(Regex("\\s+")).filter { it.isNotEmpty() }
        val featuredOnly = chipFeatured.isChecked
        val githubOnly = chipGithub.isChecked

        val result = data.apps.filter { app ->
            (selectedCategory == null || app.category == selectedCategory) &&
                (!featuredOnly || app.featured) &&
                (!githubOnly || app.github) &&
                terms.all { app.searchText.contains(it) }
        }.sortedWith(compareByDescending<RootApp> { it.featured }.thenBy { it.name.lowercase() })

        appsAdapter.submit(result)
        resultCount.text = resources.getQuantityString(R.plurals.result_count, result.size, result.size)
        emptyView.visibility = if (result.isEmpty()) View.VISIBLE else View.GONE
        if (scrollToTop) appsList.scrollToPosition(0)
    }

    /* ----------------------------- Devices ----------------------------- */

    private fun setupDevicesPage() {
        val rows = mutableListOf<DeviceRow>()
        rows += DeviceRow.Header(
            "Bootloader unlock by brand",
            "Permanent root (Magisk, KernelSU, APatch) needs an unlocked bootloader. Tap a brand for its rooting guide.",
        )
        data.brands.forEach { rows += DeviceRow.BrandRow(it) }

        if (data.tempRoot.isNotEmpty()) {
            rows += DeviceRow.Header(
                "Root without unlocking (temporary)",
                "These projects give in-memory root on a locked bootloader, only for the exact models and firmware listed. Root is lost on a full reboot. Tap to open the GitHub repository.",
            )
            data.tempRoot.forEach { rows += DeviceRow.TempRow(it) }
        }

        if (data.frameworkPicks.isNotEmpty()) {
            rows += DeviceRow.Header("Which root solution should I use?", "")
            data.frameworkPicks.forEach { rows += DeviceRow.PickRow(it) }
        }

        val list = pageDevices as RecyclerView
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = DevicesAdapter(rows)
    }

    /* ------------------------------ About ------------------------------ */

    private fun setupAboutPage() {
        val version = try {
            packageManager.getPackageInfo(packageName, 0).versionName ?: ""
        } catch (e: Exception) {
            ""
        }
        findViewById<TextView>(R.id.about_version).text = "Version $version · data from ${data.generated}"
        val githubCount = data.apps.count { it.github }
        findViewById<TextView>(R.id.about_stats).text =
            "${data.apps.size} apps · $githubCount on GitHub · ${data.categories.size} categories\n" +
                "${data.brands.size} brands · ${data.tempRoot.size} temporary-root projects"
        findViewById<MaterialButton>(R.id.btn_repo).setOnClickListener { Links.open(this, data.source) }
        findViewById<MaterialButton>(R.id.btn_issues).setOnClickListener { Links.open(this, data.source + "/issues") }
    }

    companion object {
        private const val KEY_TAB = "tab"
        private const val KEY_QUERY = "query"
        private const val KEY_CATEGORY = "category"
        private const val KEY_FEATURED = "featured"
        private const val KEY_GITHUB = "github"
    }
}
